import Link from "next/link";

export default function Datenschutz(){
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <div className="mb-8">
        <Link href="/" className="text-sm font-semibold text-zinc-600 hover:text-black inline-flex items-center gap-1">
          ← Zurück zur Startseite
        </Link>
      </div>
      <h1 className="text-3xl font-bold">Datenschutz – DSGVO</h1>
      <div className="mt-8 space-y-6 text-zinc-700 leading-relaxed text-sm">
        <h2 className="font-bold text-base">1. Verantwortlicher</h2>
        <p>Igor Kazazic<br/>Segeparksgatan 18<br/>212 50 Malmö, Schweden<br/>E-Mail: igorkazazic1989@gmail.com<br/>Telefon: +46 70 630 08 38</p>

        <h2 className="font-bold text-base">2. Hosting und Zugriffsdaten</h2>
        <p>Wir hosten bei Vercel Inc., 340 S Lemon Ave #4133 Walnut, CA 91789, USA. Vercel verarbeitet IP-Adresse, User-Agent und Zeitstempel in Server-Logs zur Sicherstellung des Betriebs (Art.6 Abs.1 lit.f DSGVO).</p>

        <h2 className="font-bold text-base">3. Beleg-Upload (Kernfunktion)</h2>
        <p>Wenn Sie einen Beleg (PDF/JPG/PNG) hochladen, wird der Inhalt zur Texterkennung an Anthropic PBC, USA (Claude API) gesendet. Rechtsgrundlage ist Art.6 Abs.1 lit.b DSGVO (Vertragserfüllung). Da es sich um eine Datenübermittlung in ein Drittland ohne Angemessenheitsbeschluss handelt, stützt sich diese Übermittlung auf die EU-Standardvertragsklauseln (SCC) gemäß Art.46 Abs.2 lit.c DSGVO, die Bestandteil von Anthropics Data Processing Addendum (DPA) sind. Ihre Belege werden nach der Erstellung der DATEV-CSV sofort gelöscht und nicht gespeichert.</p>

        <h2 className="font-bold text-base">4. Gratis-Limit</h2>
        <p>Zur Durchsetzung des Gratis-Limits speichern wir eine zufällige ID in Ihrem localStorage (b2d_fp) und einen anonymisierten IP-Hash. Rechtsgrundlage Art.6 Abs.1 lit.f (Missbrauchsschutz). Löschung bei Leeren des Browser-Speichers.</p>

        <h2 className="font-bold text-base">5. Zahlung</h2>
        <p>Bei Kauf von Unlimited leiten wir Sie zu Stripe Payments Europe Ltd., 1 Grand Canal Street Lower, Dublin, Irland weiter. Stripe verarbeitet Zahlungsdaten eigenverantwortlich (Art.6 Abs.1 lit.b). Wir speichern keine Kartendaten.</p>

        <h2 className="font-bold text-base">6. Speicherdauer</h2>
        <p>Belegdaten: 0 Tage – sofortige Löschung nach Verarbeitung. Nutzungszähler: bis Löschung localStorage. Rechnungsdaten: nach gesetzlichen Aufbewahrungsfristen bei Stripe.</p>

        <h2 className="font-bold text-base">7. Ihre Rechte</h2>
        <p>Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch und Datenübertragbarkeit (Art.15-21 DSGVO). Kontaktieren Sie uns dazu per E-Mail. Sie haben zudem das Recht auf Beschwerde bei einer Aufsichtsbehörde.</p>

        <h2 className="font-bold text-base">8. Cookies / Tracking</h2>
        <p>Wir setzen keine Marketing-Cookies und kein Google Analytics. Nur technisch notwendiger localStorage für das Limit. Wenn wir später Analytics einsetzen, holen wir vorher Ihre Einwilligung über ein Consent-Banner ein (TTDSG).</p>
      </div>
      <div className="mt-12 pt-6 border-t">
        <Link href="/" className="text-sm font-semibold text-zinc-600 hover:text-black">
          ← Zurück zur Startseite
        </Link>
      </div>
    </div>
  )
}
